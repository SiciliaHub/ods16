# OpenDataSicilia 2016 - workshop QGIS: dai dati alle mappe

materiale esercitazione

relatore Salvatore Fiandaca

fonte dati:

OpenStreetMap OSM 

ISTAT http://www.istat.it/it/archivio/124086

INGVterremoti http://goo.gl/eQOOBa

output stampa

<img src="https://github.com/pigreco/ODS16_QGIS/blob/master/stampa.jpeg" width =600>




